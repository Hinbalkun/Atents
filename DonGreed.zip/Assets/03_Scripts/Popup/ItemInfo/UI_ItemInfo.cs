﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

public class UI_ItemInfo : MonoBehaviour
{
	#region INSPECTOR

	UI_InventorySlot	m_slot;
	Text				m_lbName;

	#endregion

	public void SetData()
	{

	}

	void Refresh()
	{

	}


}
